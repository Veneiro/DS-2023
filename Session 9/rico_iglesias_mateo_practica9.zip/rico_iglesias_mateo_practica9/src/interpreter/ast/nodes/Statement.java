package interpreter.ast.nodes;

public interface Statement extends Node 
{    
}
