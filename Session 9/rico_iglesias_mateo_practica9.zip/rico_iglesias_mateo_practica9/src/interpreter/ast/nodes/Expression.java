package interpreter.ast.nodes;

public interface Expression extends Node {
    
}
