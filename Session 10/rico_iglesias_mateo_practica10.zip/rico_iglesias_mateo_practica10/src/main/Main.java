package main;

import game.BallGame;
import platform.Platform;
import platform.android.AndroidAPI;
import platform.android.AndroidAPIAdapter;
import platform.playstation.Playstation5API;
import platform.playstation.Playstation5APIAdapter;
import platform.windows.WindowsAPI;
import platform.windows.WindowsAPIAdapter;

public class Main {
	public static void main(String[] args) {

		Platform android = new AndroidAPIAdapter(new AndroidAPI());
		Platform playstation = new Playstation5APIAdapter(
				new Playstation5API());
		Platform windows = new WindowsAPIAdapter(new WindowsAPI());

		BallGame game = new BallGame(android);
		game.play();
	}
}
