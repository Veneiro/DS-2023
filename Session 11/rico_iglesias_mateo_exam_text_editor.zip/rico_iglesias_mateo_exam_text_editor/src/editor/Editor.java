package editor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import editor.macros.AbrirMacro;
import editor.macros.BorrarMacro;
import editor.macros.InsertarMacro;
import editor.macros.Macro;
import editor.macros.ReemplazarMacro;

public class Editor {
	
	private StringBuilder texto = new StringBuilder();
	private String[] lines;
	private boolean recording = false;
	private List<Macro> macros = new ArrayList<>();
	
	public Editor(StringBuilder texto) {
		this.texto = texto;
	}

	public StringBuilder doMacro(String[] line) throws IOException {
		this.lines = line;
		if (lines[0].equals("abre")) {
			Macro macro = new AbrirMacro();
			doM(macro);
		} else if (lines[0].startsWith("ins")) {
			Macro macro = new InsertarMacro();
			doM(macro);
		} else if (lines[0].startsWith("borr")) {
			Macro macro = new BorrarMacro();
			doM(macro);
		} else if (lines[0].startsWith("reem")) {
			Macro macro = new ReemplazarMacro();
			doM(macro);
		} else if (lines[0].startsWith("graba")) {
			this.recording = true;
		} else if (lines[0].startsWith("para")) {
			this.recording = false;
		} else if (lines[0].startsWith("ejecuta")) {
			for (Macro macro : macros) {
				macro.execute(this);
			};
		} else {
			System.out.println("Instrucción desconocida");
		}
		return texto;
	}
	
	private void doM(Macro macro) throws IOException {
		if(!recording) {
			texto = macro.execute(this);
		} else {
			macros.add(macro);
		}
	}
	
	public String getLine(int i) {
		return this.lines[i];
	}
	
	public String[] getLines() {
		return this.lines;
	}
	
	public StringBuilder getTexto() {
		return this.texto;
	}

}
