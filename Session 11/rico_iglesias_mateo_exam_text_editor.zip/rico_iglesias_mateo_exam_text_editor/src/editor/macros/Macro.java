package editor.macros;

import java.io.IOException;

import editor.Editor;

public interface Macro {

	public StringBuilder execute(Editor editor) throws IOException;
}
