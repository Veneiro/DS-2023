package editor.macros;

import java.io.IOException;

import editor.Editor;

public class InsertarMacro implements Macro {

	@Override
	public StringBuilder execute(Editor editor) throws IOException {
		StringBuilder texto = new StringBuilder();
		for (int i = 1; i < editor.getLines().length; i++) {
			texto.append(editor.getLine(i) + " ");
		}
		return texto;
	}

}
