package editor.macros;

import java.io.IOException;
import java.util.regex.Pattern;

import editor.Editor;

public class ReemplazarMacro implements Macro {

	@Override
	public StringBuilder execute(Editor editor) throws IOException {
		return new StringBuilder(editor.getTexto().toString().replaceAll(
				Pattern.quote(editor.getLine(1)), editor.getLine(2)));
	}

}
