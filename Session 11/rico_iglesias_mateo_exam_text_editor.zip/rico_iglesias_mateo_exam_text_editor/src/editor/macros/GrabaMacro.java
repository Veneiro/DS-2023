package editor.macros;

import java.io.IOException;

import editor.Editor;

public class GrabaMacro implements Macro {

	@Override
	public StringBuilder execute(Editor editor) throws IOException {
		return null;
	}

}
