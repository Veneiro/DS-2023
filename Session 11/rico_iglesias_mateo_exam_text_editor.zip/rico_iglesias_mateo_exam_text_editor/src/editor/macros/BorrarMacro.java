package editor.macros;

import java.io.IOException;

import editor.Editor;

public class BorrarMacro implements Macro {

	@Override
	public StringBuilder execute(Editor editor) throws IOException {
		StringBuilder texto = new StringBuilder();
		int indexOfLastWord = texto.toString().trim().lastIndexOf(" ");
		if (indexOfLastWord == -1)
			texto = new StringBuilder("");
		else
			texto.setLength(indexOfLastWord + 1);
		
		return texto;
	}

	
}
