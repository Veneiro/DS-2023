package model;

import google.maps.Coordinates;
import google.maps.GPS;
import google.maps.MapElement;

public class RestaurantElements implements MapElement {

	private Restaurant restaurant;
	
	public RestaurantElements(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
	
	@Override
	public String getTitle() {
		return this.restaurant.getName();
	}

	@Override
	public Coordinates getCoordinates() {
		return new GPS().getCoordinates(this.restaurant.getAddress());
	}

	@Override
	public String getHTMLInfo() {
		String s = "";
		s += this.restaurant.getName() + " \n";
		s += this.restaurant.getAddress() + " \n";
		s += this.restaurant.getPhone() + " \n";
		return s;
	}

	@Override
	public void open() {
		this.restaurant.call();
	}
	
}
