package model;

import google.maps.Coordinates;
import google.maps.MapElement;

public class PhotoElements implements MapElement {
	
	private Photo photo;

	public PhotoElements(Photo photo) {
		this.photo = photo;
	}
	
	@Override
	public String getTitle() {
		return this.photo.getDescription();
	}

	@Override
	public Coordinates getCoordinates() {
		return this.photo.getCoordinates();
	}

	@Override
	public String getHTMLInfo() {
		String s = "";
		s+= this.photo.getDescription() + " \n";
		s+= this.photo.getUser() + " \n";
		s+= this.photo.getCoordinates() + " \n";
		return s;
	}

	@Override
	public void open() {
		System.out.println("Foto en pantalla completa...");
	}

}
