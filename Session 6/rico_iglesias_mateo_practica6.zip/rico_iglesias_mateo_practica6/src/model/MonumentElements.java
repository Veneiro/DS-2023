package model;

import google.maps.Coordinates;
import google.maps.GPS;
import google.maps.MapElement;

public class MonumentElements implements MapElement {

	private Monument monument;

	public MonumentElements(Monument monument) {
		this.monument = monument;
	}
	
	@Override
	public String getTitle() {
		return this.monument.getName();
	}

	@Override
	public Coordinates getCoordinates() {
		return new GPS().getCoordinates(this.monument.getAddress());
	}

	@Override
	public String getHTMLInfo() {
		String s = "";
		s+= this.monument.getName() + " \n";
		s+= this.monument.getAuthor() + " \n";
		s+= this.monument.getAddress() + " \n";
		return s;
	}

	@Override
	public void open() {
		new GPS().getDirectionsTo(this.monument.getAddress());
	}

}
