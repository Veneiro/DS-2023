package form;

import java.util.List;

public interface Editable {

	List<String> getFields();

	void setFieldValue(int fieldPos, String value);

	String getFieldValue(int fieldPos);

	void print();
}