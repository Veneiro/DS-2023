package form;

import java.util.Arrays;
import java.util.List;

import model.Photo;

public class EditablePhoto implements Editable {

	private Photo p;
	
	public EditablePhoto(Photo photo) {
		this.p = photo;
	}
	
	public List<String> getFields(){
		return Arrays.asList("Usuario","Descripción");
	}
	
	public void setFieldValue(int fieldPos, String value) {
		switch (fieldPos) {
		case 0:
			p.setUser(value);
			break;
		case 1:
			p.setDescription(value);
			break;
		default:
			throw new IllegalArgumentException("Unexpected value: " + fieldPos);
		}
	}
	
	public String getFieldValue(int fieldPos) {
		switch (fieldPos) {
		case 0:
			return p.getUser();
		case 1:
			return p.getDescription();
		default:
			throw new IllegalArgumentException("Unexpected value: " + fieldPos);
		}
	}
	
	public void print() {
		String s = "Info:\n";
		s += p.getUser() + "\n";
		s += p.getDescription() + "\n";
		s += p.getCoordinates() + "\n";
		System.out.println(s);
	}
}
