package form;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

// Formulario básico para usar cuando se quieran pedir sólo dos valores sobre algo.
//
public class Form {

	public void edit(Editable editable) {
		System.out.println("Editando el monumento...");

		System.out.println("Valores actuales:");
		editable.print();

		System.out.println("Escriba nuevos valores (dejar en blanco para dejar el valor actual):");
		int i = 0;
		for (String label: editable.getFields()) {
			System.out.print(" - " + label + ": ");
			String value = readLine();
			if (value.length() > 0)
				editable.setFieldValue(i, value);
			i++;
		}	
		System.out.println("Valores finales:");
		editable.print();
	}

	private String readLine() {
		BufferedReader console = new BufferedReader(new InputStreamReader(System.in));
		do {
			try {
				return console.readLine();
			} catch (IOException ex) {
				System.out.println("Error de lectura: inténtelo de nuevo");
			}
		} while (true);
	}
	
	
}
