package form;

import java.util.Arrays;
import java.util.List;

import model.Monument;

public class EditableMonument implements Editable {

	private Monument m;
	
	public EditableMonument(Monument monument) {
		this.m = monument;
	}
	
	@Override
	public List<String> getFields(){
		return Arrays.asList("Nombre", "Dirección");
	}
	
	@Override
	public void setFieldValue(int fieldPos, String value) {
		switch (fieldPos) {
		case 0:
			m.setName(value);
			break;
		case 1:
			m.setAddress(value);
			break;
		default:
			throw new IllegalArgumentException("Unexpected value: " + fieldPos);
		}
	}
	
	@Override
	public String getFieldValue(int fieldPos) {
		switch (fieldPos) {
		case 0:
			return m.getName();
		case 1:
			return m.getAddress();
		default:
			throw new IllegalArgumentException("Unexpected value: " + fieldPos);
		}
	}
	
	public void print() {
		String s = "Info:\n";
		s += m.getName() + "\n";
		s += m.getAddress() + "\n";
		s += m.getAuthor() + "\n";
		System.out.println(s);
	}
}
