package form;

import java.util.Arrays;
import java.util.List;

import model.Restaurant;

public class EditableRestaurant implements Editable {
	
	private Restaurant r;
	
	public EditableRestaurant(Restaurant r) {
		this.r = r;
	}
	
	public List<String> getFields(){
		return Arrays.asList("Nombre", "Dirección");
	}
	
	public void setFieldValue(int fieldPos, String value) {
		switch (fieldPos) {
		case 0: {
			r.setNombre(value);
			break;
		} case 1: {
			r.setDireccion(value);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + fieldPos);
		}
	}
	
	public String getFieldValue(int fieldPos) {
		switch(fieldPos) {
		case 0:
			return r.getName();
		case 1:
			return r.getAddress();
		default:
			throw new IllegalArgumentException("Unexpected value: " + fieldPos);
		}
	}
	
	public void print() {
		String s = "Info:\n";
		s += r.getName() + "\n";
		s += r.getAddress() + "\n";
		s += r.getPhone() + "\n";
		System.out.println(s);
	}
}
