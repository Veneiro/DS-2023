package form.validator;

public interface Validador {
	public boolean validate(String value);
}
