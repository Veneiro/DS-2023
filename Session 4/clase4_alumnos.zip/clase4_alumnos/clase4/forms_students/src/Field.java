public interface Field {
	public void askUser();
	public String getValue();
}
