package editor.historial.actions;

public interface Action {
	public void redo();
	public void undo();
}
