package actions;

public interface Action {

	public void doAction();
}
