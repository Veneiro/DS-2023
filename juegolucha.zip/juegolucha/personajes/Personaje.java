package juegolucha.personajes;

public interface Personaje {
    String getNombre();
    int atacar();
    int defender();

}
