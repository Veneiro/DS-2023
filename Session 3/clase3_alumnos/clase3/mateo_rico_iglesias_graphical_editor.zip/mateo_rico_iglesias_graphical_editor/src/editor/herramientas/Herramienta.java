package editor.herramientas;

public interface Herramienta {

	void clickOn(final int p0, final int p1);

	void moveTo(final int p0, final int p1);

	void release();
}
