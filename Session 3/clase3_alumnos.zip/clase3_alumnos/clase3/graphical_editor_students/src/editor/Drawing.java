package editor;

public class Drawing  {
	
	/*
	public addFigure(...) {
		// TO DO
	}
	*/

	public void draw() {
		System.out.println("Estoy vacío (por ahora)");
	}
}
