package libros.modelo;

public class Parrafo {

    private String texto;

    public Parrafo(String texto) {
        this.texto = texto;
    }

    public String getTexto() {
        return texto;
    }
}
